from skyfield.api import load, EarthSatellite
import simplekml

# Load time scale
ts = load.timescale()
times = ts.utc(2024, 5, 8, range(0, 90, 5))  # 90 minutes at 5 min intervals

# Load all TLEs
satellites = {}
with open("virtual_satellites.tle") as f:
    lines = f.readlines()
    for i in range(0, len(lines), 2):
        line1 = lines[i].strip()
        line2 = lines[i+1].strip()
        satnum = line1.split()[1]  # e.g., "10000"
        satellites[satnum] = EarthSatellite(line1, line2, f"Sat {satnum}", ts)

# Create KML
kml = simplekml.Kml()

# Plot each satellite's ground track
for satnum, sat in satellites.items():
    coords = []
    for t in times:
        sp = sat.at(t).subpoint()
        lon = sp.longitude.degrees
        lat = sp.latitude.degrees
        coords.append((lon, lat))
    
    # Draw path using LineString
    path = kml.newlinestring(name=f"Sat {satnum}")
    path.coords = coords
    #path.altitudemode = simplekml.AltitudeMode.clampToGround
    path.style.linestyle.width = 2
    path.style.linestyle.color = simplekml.Color.red  # red paths for visibility

kml.save("virtual_constellation.kml")
